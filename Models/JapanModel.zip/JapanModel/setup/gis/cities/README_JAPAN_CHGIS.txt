Tokugawa Japan GIS - Demo Version
(c) Harvard Yenching Inst 2004

Date:  1664, 1828, 1869
Source: CHGIS (China Historical Geographic Information System), Harvard Yenching Institute
URL: http://www.fas.harvard.edu/~chgis/japan

------------------
For non-commercial academic purposes only.

------------------

Use of this data implies agreement with the End User License Agreement available here:

http://chgis.fas.harvard.edu/webmap/japan/japan_eula.html