Japan GIS - Coastal Boundaries

Date: early 1990s
Source: DCW  (Digital Chart of the World)
URL: http://www.maproom.psu.edu/dcw/

------------------
For non-commercial academic purposes only.
------------------

